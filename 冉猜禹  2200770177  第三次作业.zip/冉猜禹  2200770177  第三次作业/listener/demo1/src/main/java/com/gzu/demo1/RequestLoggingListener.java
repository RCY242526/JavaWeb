package com.gzu.demo1;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpServletRequest;

@WebListener
public class RequestLoggingListener implements ServletRequestListener {

    // 当请求初始化时，记录开始时间
    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        long startTime = System.currentTimeMillis();
        sre.getServletRequest().setAttribute("startTime", startTime);

        // 使用 System.out.println 输出到控制台
        System.out.println("Request received at: " + startTime);
    }

    // 当请求结束时，记录请求的详细信息
    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        try {
            long startTime = (long) sre.getServletRequest().getAttribute("startTime");
            long processingTime = System.currentTimeMillis() - startTime;

            HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
            String clientIP = request.getRemoteAddr();
            String requestMethod = request.getMethod();
            String requestURI = request.getRequestURI();
            String queryString = request.getQueryString() != null ? request.getQueryString() : "N/A";
            String userAgent = request.getHeader("User-Agent");

            // 使用 System.out.println 输出请求的详细信息
            System.out.println("Request Time: " + startTime);
            System.out.println("Client IP: " + clientIP);
            System.out.println("Request Method: " + requestMethod);
            System.out.println("Request URI: " + requestURI);
            System.out.println("Query String: " + queryString);
            System.out.println("User-Agent: " + userAgent);
            System.out.println("Request Processing Time: " + processingTime + " ms");
        } catch (Exception e) {
            System.out.println("Error logging request details: " + e.getMessage());
        }
    }
}
